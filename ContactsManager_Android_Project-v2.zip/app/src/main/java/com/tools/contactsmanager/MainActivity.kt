package com.tools.contactsmanager

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentProviderOperation
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val PERMISSION_REQUEST_CODE = 101

    private lateinit var etCountryCode: EditText
    private lateinit var etCustomPrefix: EditText
    private lateinit var etBulkInput: EditText
    private lateinit var cbDualNumbers: CheckBox
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etCountryCode = findViewById(R.id.etCountryCode)
        etCustomPrefix = findViewById(R.id.etCustomPrefix)
        etBulkInput = findViewById(R.id.etBulkInput)
        cbDualNumbers = findViewById(R.id.cbDualNumbers)
        tvStatus = findViewById(R.id.tvStatus)

        checkAndRequestPermissions()

        findViewById<Button>(R.id.btnImportAll).setOnClickListener {
            runWithPermission { importAllContactsFromPhone(showToast = true) }
        }

        findViewById<Button>(R.id.btnAddCode).setOnClickListener {
            runWithPermission { processExistingContacts(OperationType.ADD_COUNTRY_CODE) }
        }

        findViewById<Button>(R.id.btnRemoveCode).setOnClickListener {
            runWithPermission { processExistingContacts(OperationType.REMOVE_COUNTRY_CODE) }
        }

        findViewById<Button>(R.id.btnMergeDual).setOnClickListener {
            runWithPermission { mergeDualNumbersPerContact() }
        }

        findViewById<Button>(R.id.btnAddCustom).setOnClickListener {
            runWithPermission { processExistingContacts(OperationType.ADD_CUSTOM_PREFIX) }
        }

        findViewById<Button>(R.id.btnCopyList).setOnClickListener {
            val content = etBulkInput.text.toString()
            if (content.isBlank()) {
                Toast.makeText(this, "القائمة فارغة، اضغط استيراد أولاً", Toast.LENGTH_SHORT).show()
            } else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("ContactsList", content))
                Toast.makeText(this, "تم نسخ جميع الأسماء والأرقام إلى الحافظة", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnShareList).setOnClickListener {
            val content = etBulkInput.text.toString()
            if (content.isBlank()) {
                Toast.makeText(this, "القائمة فارغة، اضغط استيراد أولاً", Toast.LENGTH_SHORT).show()
            } else {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, content)
                    type = "text/plain"
                }
                startActivity(Intent.createChooser(sendIntent, "مشاركة أو حفظ قائمة الأسماء والأرقام"))
            }
        }

        findViewById<Button>(R.id.btnClearList).setOnClickListener {
            etBulkInput.text.clear()
            tvStatus.text = "الحالة: تم مسح مربع القائمة"
        }

        findViewById<Button>(R.id.btnMergeText).setOnClickListener {
            runWithPermission { importAndMergeBulkList() }
        }
    }

    private enum class OperationType {
        ADD_COUNTRY_CODE,
        REMOVE_COUNTRY_CODE,
        ADD_CUSTOM_PREFIX
    }

    private fun checkAndRequestPermissions(): Boolean {
        val readGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
        val writeGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED
        if (!readGranted || !writeGranted) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS),
                PERMISSION_REQUEST_CODE
            )
            return false
        }
        return true
    }

    private fun runWithPermission(action: () -> Unit) {
        if (checkAndRequestPermissions()) {
            action()
        } else {
            Toast.makeText(this, "يرجى منح صلاحية الوصول لجهات الاتصال أولاً", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cleanNumber(raw: String): String {
        return raw.replace(Regex("[\\s\\-().]"), "")
    }

    private fun toInternational(number: String, countryCode: String): String {
        val clean = cleanNumber(number)
        val code = countryCode.trim()
        val rawCode = code.removePrefix("+")

        return when {
            clean.startsWith(code) -> clean
            clean.startsWith("00$rawCode") -> "+${clean.removePrefix("00")}"
            clean.startsWith(rawCode) && clean.length > 9 -> "+$clean"
            clean.startsWith("0") -> "$code${clean.removePrefix("0")}"
            else -> "$code$clean"
        }
    }

    private fun toLocal(number: String, countryCode: String): String {
        val clean = cleanNumber(number)
        val rawCode = countryCode.trim().removePrefix("+")

        return when {
            clean.startsWith("+$rawCode") -> "0${clean.removePrefix("+$rawCode")}"
            clean.startsWith("00$rawCode") -> "0${clean.removePrefix("00$rawCode")}"
            clean.startsWith(rawCode) && clean.length > 9 -> "0${clean.removePrefix(rawCode)}"
            else -> clean
        }
    }

    // استيراد جميع الأسماء والأرقام من ذاكرة الهاتف وعرضها في التطبيق
    private fun importAllContactsFromPhone(showToast: Boolean = true) {
        tvStatus.text = "الحالة: جاري استيراد جميع الأسماء والأرقام من الجوال..."

        lifecycleScope.launch(Dispatchers.IO) {
            val uniqueEntries = LinkedHashSet<String>()
            val uniqueNames = HashSet<String>()

            val cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
            )

            cursor?.use {
                val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (it.moveToNext()) {
                    val name = it.getString(nameIdx)?.trim() ?: "بدون اسم"
                    val rawNum = it.getString(numIdx)?.trim() ?: continue
                    val cleaned = cleanNumber(rawNum)
                    if (cleaned.isNotEmpty()) {
                        uniqueNames.add(name)
                        uniqueEntries.add("$name - $cleaned")
                    }
                }
            }

            val formattedList = uniqueEntries.joinToString("\n")
            val totalNumbers = uniqueEntries.size
            val totalNames = uniqueNames.size

            withContext(Dispatchers.Main) {
                etBulkInput.setText(formattedList)
                tvStatus.text = "تم استيراد $totalNumbers رقم لـ $totalNames جهة اتصال من الجوال بنجاح!"
                if (showToast) {
                    Toast.makeText(
                        this@MainActivity,
                        "تم استيراد $totalNumbers رقم من الجوال",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun processExistingContacts(type: OperationType) {
        val countryCode = etCountryCode.text.toString().trim()
        val customPrefix = etCustomPrefix.text.toString().trim()

        if ((type == OperationType.ADD_COUNTRY_CODE || type == OperationType.REMOVE_COUNTRY_CODE) && countryCode.isEmpty()) {
            Toast.makeText(this, "أدخل مقدمة الدولة أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        if (type == OperationType.ADD_CUSTOM_PREFIX && customPrefix.isEmpty()) {
            Toast.makeText(this, "أدخل الرقم أو البادئة المخصصة أولاً", Toast.LENGTH_SHORT).show()
            return
        }

        tvStatus.text = "الحالة: جاري معالجة الأرقام..."

        lifecycleScope.launch(Dispatchers.IO) {
            val ops = ArrayList<ContentProviderOperation>()
            var updatedCount = 0

            val cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone._ID,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )

            cursor?.use {
                val idIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (it.moveToNext()) {
                    val dataId = it.getLong(idIdx)
                    val oldNumber = it.getString(numIdx) ?: continue

                    val newNumber = when (type) {
                        OperationType.ADD_COUNTRY_CODE -> toInternational(oldNumber, countryCode)
                        OperationType.REMOVE_COUNTRY_CODE -> toLocal(oldNumber, countryCode)
                        OperationType.ADD_CUSTOM_PREFIX -> "$customPrefix${cleanNumber(oldNumber)}"
                    }

                    if (newNumber != oldNumber) {
                        ops.add(
                            ContentProviderOperation.newUpdate(ContactsContract.Data.CONTENT_URI)
                                .withSelection("${ContactsContract.Data._ID}=?", arrayOf(dataId.toString()))
                                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, newNumber)
                                .build()
                        )
                        updatedCount++
                    }

                    if (ops.size >= 400) {
                        contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                        ops.clear()
                    }
                }
            }

            if (ops.isNotEmpty()) {
                contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            }

            withContext(Dispatchers.Main) {
                tvStatus.text = "تمت العملية بنجاح! تم تحديث $updatedCount رقم."
                if (etBulkInput.text.isNotBlank()) {
                    importAllContactsFromPhone(showToast = false)
                }
            }
        }
    }

    private fun mergeDualNumbersPerContact() {
        val countryCode = etCountryCode.text.toString().trim()
        if (countryCode.isEmpty()) {
            Toast.makeText(this, "أدخل مقدمة الدولة أولاً", Toast.LENGTH_SHORT).show()
            return
        }

        tvStatus.text = "الحالة: جاري دمج الرقمين (بمقدمة وبدون مقدمة) لكل اسم..."

        lifecycleScope.launch(Dispatchers.IO) {
            val contactNumbersMap = mutableMapOf<Long, MutableSet<String>>()

            val cursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.RAW_CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )

            cursor?.use {
                val rawIdIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.RAW_CONTACT_ID)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (it.moveToNext()) {
                    val rawContactId = it.getLong(rawIdIdx)
                    val num = cleanNumber(it.getString(numIdx) ?: continue)
                    contactNumbersMap.getOrPut(rawContactId) { mutableSetOf() }.add(num)
                }
            }

            val ops = ArrayList<ContentProviderOperation>()
            var addedNumbersCount = 0

            for ((rawContactId, existingNumbers) in contactNumbersMap) {
                val sampleNumber = existingNumbers.firstOrNull() ?: continue
                val intlNum = toInternational(sampleNumber, countryCode)
                val localNum = toLocal(sampleNumber, countryCode)

                if (!existingNumbers.contains(intlNum)) {
                    ops.add(buildInsertPhoneOp(rawContactId, intlNum))
                    addedNumbersCount++
                }
                if (!existingNumbers.contains(localNum)) {
                    ops.add(buildInsertPhoneOp(rawContactId, localNum))
                    addedNumbersCount++
                }

                if (ops.size >= 400) {
                    contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                    ops.clear()
                }
            }

            if (ops.isNotEmpty()) {
                contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            }

            withContext(Dispatchers.Main) {
                tvStatus.text = "اكتمل الدمج! تم إضافة $addedNumbersCount رقم مكمل لجهات الاتصال."
                if (etBulkInput.text.isNotBlank()) {
                    importAllContactsFromPhone(showToast = false)
                }
            }
        }
    }

    private fun importAndMergeBulkList() {
        val rawText = etBulkInput.text.toString().trim()
        val countryCode = etCountryCode.text.toString().trim()
        val saveDual = cbDualNumbers.isChecked

        if (rawText.isEmpty()) {
            Toast.makeText(this, "ألصق أو استورد قائمة الأسماء والأرقام أولاً", Toast.LENGTH_SHORT).show()
            return
        }

        tvStatus.text = "الحالة: جاري دمج القائمة مع جهات الاتصال..."

        lifecycleScope.launch(Dispatchers.IO) {
            val existingNameToRawId = mutableMapOf<String, Long>()
            val existingNumbersByRawId = mutableMapOf<Long, MutableSet<String>>()

            val nameCursor = contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(
                    ContactsContract.Data.RAW_CONTACT_ID,
                    ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME
                ),
                "${ContactsContract.Data.MIMETYPE}=?",
                arrayOf(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE),
                null
            )
            nameCursor?.use {
                val idIdx = it.getColumnIndex(ContactsContract.Data.RAW_CONTACT_ID)
                val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME)
                while (it.moveToNext()) {
                    val name = it.getString(nameIdx)?.trim() ?: continue
                    existingNameToRawId[name] = it.getLong(idIdx)
                }
            }

            val phoneCursor = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.RAW_CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )
            phoneCursor?.use {
                val rawIdIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.RAW_CONTACT_ID)
                val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (it.moveToNext()) {
                    val rawId = it.getLong(rawIdIdx)
                    val num = cleanNumber(it.getString(numIdx) ?: continue)
                    existingNumbersByRawId.getOrPut(rawId) { mutableSetOf() }.add(num)
                }
            }

            var processedCount = 0
            val lines = rawText.lines()

            for (line in lines) {
                if (line.isBlank()) continue
                val parts = line.split(Regex("[-:,،\\t]"), limit = 2)
                if (parts.size < 2) continue

                val part1 = parts[0].trim()
                val part2 = parts[1].trim()

                val (name, rawPhone) = if (part1.any { it.isDigit() } && !part2.any { it.isDigit() }) {
                    part2 to part1
                } else {
                    part1 to part2
                }

                val numbersToSave = if (saveDual && countryCode.isNotEmpty()) {
                    listOf(toInternational(rawPhone, countryCode), toLocal(rawPhone, countryCode)).distinct()
                } else {
                    listOf(cleanNumber(rawPhone))
                }

                val ops = ArrayList<ContentProviderOperation>()
                val existingRawId = existingNameToRawId[name]

                if (existingRawId != null) {
                    val existingNums = existingNumbersByRawId.getOrPut(existingRawId) { mutableSetOf() }
                    for (num in numbersToSave) {
                        if (!existingNums.contains(num)) {
                            ops.add(buildInsertPhoneOp(existingRawId, num))
                            existingNums.add(num)
                        }
                    }
                } else {
                    ops.add(
                        ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                            .build()
                    )
                    ops.add(
                        ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                            .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, name)
                            .build()
                    )
                    for (num in numbersToSave) {
                        ops.add(
                            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, num)
                                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                                .build()
                        )
                    }
                }

                if (ops.isNotEmpty()) {
                    contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                    processedCount++
                }
            }

            withContext(Dispatchers.Main) {
                tvStatus.text = "تم دمج وتحديث $processedCount جهة اتصال بنجاح!"
            }
        }
    }

    private fun buildInsertPhoneOp(rawContactId: Long, phoneNumber: String): ContentProviderOperation {
        return ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValue(ContactsContract.Data.RAW_CONTACT_ID, rawContactId)
            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
            .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phoneNumber)
            .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
            .build()
    }
}
